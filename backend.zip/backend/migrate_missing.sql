-- ============================================================
-- migrate_missing.sql
-- Safe migration: adds every table / column used by the app
-- that may be missing from an existing database.
-- Run with:  mysql -u root -p school_system < migrate_missing.sql
-- (replace school_system with your DB_NAME)
-- ============================================================

-- ─── 1. CORE TABLES (CREATE IF NOT EXISTS) ───────────────────────────────────

CREATE TABLE IF NOT EXISTS users (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  first_name   VARCHAR(100)  NOT NULL,
  last_name    VARCHAR(100)  NOT NULL,
  email        VARCHAR(191)  NOT NULL UNIQUE,
  phone        VARCHAR(30)   NULL,
  password     VARCHAR(255)  NOT NULL,
  role         ENUM('admin','super_admin','teacher','student') NOT NULL DEFAULT 'admin',
  gender       ENUM('MALE','FEMALE') NULL,
  birth_date   DATE          NULL,
  photo        VARCHAR(255)  NULL DEFAULT '',
  blood_type   ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NULL,
  is_active    TINYINT(1)    NOT NULL DEFAULT 1,
  created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS contact_infos (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fb          VARCHAR(255) NULL,
  whatsapp    VARCHAR(255) NULL,
  linkedin    VARCHAR(255) NULL,
  youtube     VARCHAR(255) NULL,
  instagram   VARCHAR(255) NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS schools (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name             VARCHAR(255)  NOT NULL,
  code             VARCHAR(50)   NULL,
  logo             VARCHAR(255)  NULL,
  logo2            VARCHAR(255)  NULL,
  admin_id         BIGINT UNSIGNED NULL,
  contact_info_id  BIGINT UNSIGNED NULL,
  type             VARCHAR(100)  NULL,
  phone_landline   VARCHAR(30)   NULL,
  phone_1          VARCHAR(30)   NULL,
  phone_2          VARCHAR(30)   NULL,
  email            VARCHAR(191)  NULL,
  fax              VARCHAR(30)   NULL,
  state            VARCHAR(100)  NULL,
  district         VARCHAR(100)  NULL,
  municipality     VARCHAR(100)  NULL,
  postal_code      VARCHAR(20)   NULL,
  po_box           VARCHAR(20)   NULL,
  address          TEXT          NULL,
  created_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS school_users (
  school_id   BIGINT UNSIGNED NOT NULL,
  user_id     BIGINT UNSIGNED NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (school_id, user_id),
  CONSTRAINT fk_su_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE,
  CONSTRAINT fk_su_user   FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS classrooms (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id   BIGINT UNSIGNED NOT NULL,
  name        VARCHAR(255) NOT NULL,
  capacity    INT          NULL,
  description TEXT         NULL,
  created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teachers (
  id                     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id                BIGINT UNSIGNED NOT NULL,
  school_id              BIGINT UNSIGNED NULL,
  employee_number        VARCHAR(50)   NULL,
  phone                  VARCHAR(30)   NULL,
  specialization         VARCHAR(255)  NULL,
  speciality             VARCHAR(255)  NULL,
  diploma                VARCHAR(255)  NULL,
  national_id            VARCHAR(50)   NULL,
  social_security_number VARCHAR(50)   NULL,
  hire_date              DATE          NULL,
  monthly_salary         DECIMAL(10,2) NULL,
  ccp_rib                VARCHAR(100)  NULL,
  preferred_pay_method   ENUM('cash','ccp') DEFAULT 'cash',
  rfid_tag               VARCHAR(100)  NULL,
  created_at             TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_t_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS formations (
  id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id           BIGINT UNSIGNED NOT NULL,
  teacher_id          BIGINT UNSIGNED NULL,
  classroom_id        BIGINT UNSIGNED NULL,
  title               VARCHAR(255)    NOT NULL,
  description         TEXT            NULL,
  image               VARCHAR(255)    NULL,
  duration_hours      INT             NULL,
  price               DECIMAL(10,2)   NOT NULL DEFAULT 0,
  price_monthly       DECIMAL(10,2)   NULL,
  price_3_months      DECIMAL(10,2)   NULL,
  price_1_year        DECIMAL(10,2)   NULL,
  type                VARCHAR(50)     NOT NULL DEFAULT 'formation',
  subscription_period ENUM('1_month','3_months','1_year') NULL,
  niveau              VARCHAR(100)    NOT NULL DEFAULT 'begin',
  places              INT             NOT NULL DEFAULT 0,
  status              ENUM('open','closed') NOT NULL DEFAULT 'open',
  start_date          DATE            NULL,
  end_date            DATE            NULL,
  created_at          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `groups` (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  formation_id BIGINT UNSIGNED NOT NULL,
  teacher_id   BIGINT UNSIGNED NULL,
  classroom_id BIGINT UNSIGNED NULL,
  name         VARCHAR(255)    NOT NULL,
  start_date   DATE            NULL,
  end_date     DATE            NULL,
  max_students INT             NOT NULL DEFAULT 30,
  created_at   TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS students (
  id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id              BIGINT UNSIGNED NOT NULL,
  school_id            BIGINT UNSIGNED NULL,
  formation_id         BIGINT UNSIGNED NULL,
  registration_number  VARCHAR(50)     NULL,
  rfid_tag             VARCHAR(100)    NULL,
  parent_name          VARCHAR(255)    NULL,
  parent_id_number     VARCHAR(50)     NULL,
  parent_phone         VARCHAR(30)     NULL,
  phone1_has_whatsapp  TINYINT(1)      DEFAULT 0,
  phone1_has_viber     TINYINT(1)      DEFAULT 0,
  phone1_has_telegram  TINYINT(1)      DEFAULT 0,
  parent_phone2        VARCHAR(30)     NULL,
  phone2_has_whatsapp  TINYINT(1)      DEFAULT 0,
  phone2_has_viber     TINYINT(1)      DEFAULT 0,
  phone2_has_telegram  TINYINT(1)      DEFAULT 0,
  guardian_name        VARCHAR(255)    NULL,
  guardian_relationship VARCHAR(100)   NULL,
  guardian_id_number   VARCHAR(50)     NULL,
  health_notes         TEXT            NULL,
  parents_status       ENUM('together','divorced','father_deceased','mother_deceased','both_deceased','other') NULL,
  enrollment_date      DATE            NULL,
  payment_status       VARCHAR(50)     NULL,
  subscription_plan    VARCHAR(20)     NULL,
  next_payment_date    DATE            NULL,
  promo_code           VARCHAR(50)     NULL,
  discount_percent     DECIMAL(5,2)    NOT NULL DEFAULT 0,
  created_at           TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_s_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS student_groups (
  student_id  BIGINT UNSIGNED NOT NULL,
  group_id    BIGINT UNSIGNED NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (student_id, group_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── 2. ATTENDANCE TABLES ─────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS attendance (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_type    ENUM('student','teacher') NOT NULL,
  user_id      BIGINT UNSIGNED NOT NULL,
  group_id     BIGINT UNSIGNED NULL,
  date         DATE            NOT NULL,
  subject_name VARCHAR(255)    NOT NULL DEFAULT '',
  status       ENUM('present','absent','late','excused','pending') NOT NULL DEFAULT 'pending',
  scan_time    TIME            NULL,
  notes        TEXT            NULL,
  created_at   TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_attendance (user_type, user_id, group_id, date, subject_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS attendance_validations (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  group_id     BIGINT UNSIGNED NOT NULL,
  date         DATE            NOT NULL,
  subject_name VARCHAR(255)    NOT NULL DEFAULT '',
  validated_by BIGINT UNSIGNED NULL,
  created_at   TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY idx_val_unique (group_id, date, subject_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── 3. WEEKLY PROGRAM TABLES ─────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS weekly_programs (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id   BIGINT UNSIGNED NOT NULL,
  name        VARCHAR(255)    NOT NULL,
  description TEXT            NULL,
  status      ENUM('active','disabled') NOT NULL DEFAULT 'disabled',
  created_at  TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_wp_school FOREIGN KEY (school_id) REFERENCES schools(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS weekly_time_slots (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  program_id  BIGINT UNSIGNED NOT NULL,
  label       VARCHAR(50)     NOT NULL,
  start_time  TIME            NOT NULL,
  end_time    TIME            NOT NULL,
  sort_order  INT             NOT NULL DEFAULT 0,
  CONSTRAINT fk_wts_program FOREIGN KEY (program_id) REFERENCES weekly_programs(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS weekly_schedule_entries (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slot_id      BIGINT UNSIGNED NOT NULL,
  day_of_week  TINYINT         NOT NULL,
  group_id     BIGINT UNSIGNED NOT NULL,
  subject_name VARCHAR(255)    NOT NULL,
  color        VARCHAR(20)     NOT NULL DEFAULT '#4f6eff',
  classroom_id BIGINT UNSIGNED NULL,
  CONSTRAINT fk_wse_slot  FOREIGN KEY (slot_id)  REFERENCES weekly_time_slots(id) ON DELETE CASCADE,
  CONSTRAINT fk_wse_group FOREIGN KEY (group_id) REFERENCES `groups`(id)          ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── 4. PAYMENT TABLES ────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS payment_history (
  id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_id          BIGINT UNSIGNED NOT NULL,
  school_id           BIGINT UNSIGNED NOT NULL,
  amount              DECIMAL(10,2)   NOT NULL,
  payment_date        DATE            NOT NULL,
  payment_method      ENUM('cash','bank_transfer','card','other') DEFAULT 'cash',
  subscription_plan   VARCHAR(20)     NULL,
  promo_code_id       BIGINT UNSIGNED NULL,
  discount_percent    DECIMAL(5,2)    NOT NULL DEFAULT 0,
  notes               TEXT            NULL,
  recorded_by_user_id BIGINT UNSIGNED NULL,
  created_at          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ph_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT fk_ph_school  FOREIGN KEY (school_id)  REFERENCES schools(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS teacher_payments (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id       INT UNSIGNED NOT NULL,
  teacher_id      INT UNSIGNED NOT NULL,
  amount          DECIMAL(10,2) NOT NULL,
  pay_month       TINYINT       NOT NULL,
  pay_year        YEAR          NOT NULL,
  payment_date    DATE          NOT NULL,
  method          ENUM('cash','ccp') DEFAULT 'cash',
  notes           TEXT          NULL,
  treasury_tx_id  INT UNSIGNED  NULL,
  recorded_by     INT UNSIGNED  NULL,
  created_at      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_teacher_month (teacher_id, pay_month, pay_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── 5. TREASURY TABLE ────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS treasury_transactions (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id        BIGINT UNSIGNED NOT NULL,
  type             ENUM('income','expense') NOT NULL,
  category         VARCHAR(100)    NULL,
  amount           DECIMAL(10,2)   NOT NULL,
  transaction_date DATE            NOT NULL,
  notes            TEXT            NULL,
  person_name      VARCHAR(255)    NULL,
  recorded_by      BIGINT UNSIGNED NULL,
  created_at       TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── 6. OTHER TABLES ──────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS promo_codes (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  formation_id     BIGINT UNSIGNED NOT NULL,
  code             VARCHAR(50)     NOT NULL,
  discount_percent DECIMAL(5,2)    NOT NULL,
  type             ENUM('many_students','one_student') NOT NULL DEFAULT 'many_students',
  is_active        TINYINT(1)      NOT NULL DEFAULT 1,
  created_at       TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_promo_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notifications (
  id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    BIGINT UNSIGNED NOT NULL,
  message    TEXT            NOT NULL,
  is_read    TINYINT(1)      NOT NULL DEFAULT 0,
  created_at TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS landing_inquiries (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id       BIGINT UNSIGNED NULL,
  name            VARCHAR(255)    NOT NULL,
  phone           VARCHAR(30)     NULL,
  formation_title VARCHAR(255)    NULL,
  message         TEXT            NULL,
  status          ENUM('new','contacted','enrolled','cancelled') NOT NULL DEFAULT 'new',
  created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS quran_memorization (
  id            INT UNSIGNED    NOT NULL AUTO_INCREMENT PRIMARY KEY,
  school_id     INT             NOT NULL,
  student_id    INT             NOT NULL,
  group_id      INT             NULL,
  formation_id  BIGINT UNSIGNED NULL,
  cycle         VARCHAR(100)    NULL,
  session_date  DATE            NOT NULL,
  amount        VARCHAR(255)    NOT NULL,
  level         VARCHAR(100)    NULL,
  notes         TEXT            NULL,
  created_at    TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_qm_school    (school_id),
  INDEX idx_qm_student   (student_id),
  INDEX idx_qm_group     (group_id),
  INDEX idx_qm_formation (formation_id),
  INDEX idx_qm_date      (session_date),
  INDEX idx_qm_cycle     (cycle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── 7. ALTER EXISTING TABLES — add missing columns safely ───────────────────
-- Uses a stored procedure to skip columns that already exist.

DROP PROCEDURE IF EXISTS add_col_if_missing;
DELIMITER //
CREATE PROCEDURE add_col_if_missing(
  IN p_table   VARCHAR(64),
  IN p_col     VARCHAR(64),
  IN p_def     TEXT
)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE()
      AND table_name   = p_table
      AND column_name  = p_col
  ) THEN
    SET @sql = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_col, '` ', p_def);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END IF;
END //
DELIMITER ;

-- users
CALL add_col_if_missing('users', 'gender',     "ENUM('MALE','FEMALE') NULL AFTER role");
CALL add_col_if_missing('users', 'birth_date', 'DATE NULL AFTER gender');
CALL add_col_if_missing('users', 'photo',      "VARCHAR(255) NULL DEFAULT '' AFTER birth_date");
CALL add_col_if_missing('users', 'blood_type', "ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NULL AFTER photo");
CALL add_col_if_missing('users', 'is_active',  'TINYINT(1) NOT NULL DEFAULT 1');

-- schools
CALL add_col_if_missing('schools', 'logo',            'VARCHAR(255) NULL');
CALL add_col_if_missing('schools', 'logo2',           'VARCHAR(255) NULL');
CALL add_col_if_missing('schools', 'admin_id',        'BIGINT UNSIGNED NULL');
CALL add_col_if_missing('schools', 'contact_info_id', 'BIGINT UNSIGNED NULL');
CALL add_col_if_missing('schools', 'type',            'VARCHAR(100) NULL');
CALL add_col_if_missing('schools', 'phone_landline',  'VARCHAR(30) NULL');
CALL add_col_if_missing('schools', 'phone_1',         'VARCHAR(30) NULL');
CALL add_col_if_missing('schools', 'phone_2',         'VARCHAR(30) NULL');
CALL add_col_if_missing('schools', 'email',           'VARCHAR(191) NULL');
CALL add_col_if_missing('schools', 'fax',             'VARCHAR(30) NULL');
CALL add_col_if_missing('schools', 'state',           'VARCHAR(100) NULL');
CALL add_col_if_missing('schools', 'district',        'VARCHAR(100) NULL');
CALL add_col_if_missing('schools', 'municipality',    'VARCHAR(100) NULL');
CALL add_col_if_missing('schools', 'postal_code',     'VARCHAR(20) NULL');
CALL add_col_if_missing('schools', 'po_box',          'VARCHAR(20) NULL');
CALL add_col_if_missing('schools', 'address',         'TEXT NULL');

-- teachers
CALL add_col_if_missing('teachers', 'school_id',              'BIGINT UNSIGNED NULL');
CALL add_col_if_missing('teachers', 'phone',                  'VARCHAR(30) NULL');
CALL add_col_if_missing('teachers', 'speciality',             'VARCHAR(255) NULL');
CALL add_col_if_missing('teachers', 'diploma',                'VARCHAR(255) NULL');
CALL add_col_if_missing('teachers', 'national_id',            'VARCHAR(50) NULL');
CALL add_col_if_missing('teachers', 'social_security_number', 'VARCHAR(50) NULL');
CALL add_col_if_missing('teachers', 'hire_date',              'DATE NULL');
CALL add_col_if_missing('teachers', 'monthly_salary',         'DECIMAL(10,2) NULL');
CALL add_col_if_missing('teachers', 'ccp_rib',                'VARCHAR(100) NULL');
CALL add_col_if_missing('teachers', 'preferred_pay_method',   "ENUM('cash','ccp') DEFAULT 'cash'");
CALL add_col_if_missing('teachers', 'rfid_tag',               'VARCHAR(100) NULL');

-- students
CALL add_col_if_missing('students', 'school_id',             'BIGINT UNSIGNED NULL');
CALL add_col_if_missing('students', 'rfid_tag',              'VARCHAR(100) NULL');
CALL add_col_if_missing('students', 'parent_name',           'VARCHAR(255) NULL');
CALL add_col_if_missing('students', 'parent_id_number',      'VARCHAR(50) NULL');
CALL add_col_if_missing('students', 'parent_phone',          'VARCHAR(30) NULL');
CALL add_col_if_missing('students', 'phone1_has_whatsapp',   'TINYINT(1) DEFAULT 0');
CALL add_col_if_missing('students', 'phone1_has_viber',      'TINYINT(1) DEFAULT 0');
CALL add_col_if_missing('students', 'phone1_has_telegram',   'TINYINT(1) DEFAULT 0');
CALL add_col_if_missing('students', 'parent_phone2',         'VARCHAR(30) NULL');
CALL add_col_if_missing('students', 'phone2_has_whatsapp',   'TINYINT(1) DEFAULT 0');
CALL add_col_if_missing('students', 'phone2_has_viber',      'TINYINT(1) DEFAULT 0');
CALL add_col_if_missing('students', 'phone2_has_telegram',   'TINYINT(1) DEFAULT 0');
CALL add_col_if_missing('students', 'guardian_name',         'VARCHAR(255) NULL');
CALL add_col_if_missing('students', 'guardian_relationship', 'VARCHAR(100) NULL');
CALL add_col_if_missing('students', 'guardian_id_number',    'VARCHAR(50) NULL');
CALL add_col_if_missing('students', 'health_notes',          'TEXT NULL');
CALL add_col_if_missing('students', 'parents_status',        "ENUM('together','divorced','father_deceased','mother_deceased','both_deceased','other') NULL");
CALL add_col_if_missing('students', 'subscription_plan',     'VARCHAR(20) NULL');
CALL add_col_if_missing('students', 'next_payment_date',     'DATE NULL');
CALL add_col_if_missing('students', 'promo_code',            'VARCHAR(50) NULL');
CALL add_col_if_missing('students', 'discount_percent',      'DECIMAL(5,2) NOT NULL DEFAULT 0');

-- formations
CALL add_col_if_missing('formations', 'image',               'VARCHAR(255) NULL');
CALL add_col_if_missing('formations', 'classroom_id',        'BIGINT UNSIGNED NULL');
CALL add_col_if_missing('formations', 'price_monthly',       'DECIMAL(10,2) NULL');
CALL add_col_if_missing('formations', 'price_3_months',      'DECIMAL(10,2) NULL');
CALL add_col_if_missing('formations', 'price_1_year',        'DECIMAL(10,2) NULL');
CALL add_col_if_missing('formations', 'subscription_period', "ENUM('1_month','3_months','1_year') NULL");
CALL add_col_if_missing('formations', 'niveau',              "VARCHAR(100) NOT NULL DEFAULT 'begin'");
CALL add_col_if_missing('formations', 'places',              'INT NOT NULL DEFAULT 0');
CALL add_col_if_missing('formations', 'status',              "ENUM('open','closed') NOT NULL DEFAULT 'open'");
CALL add_col_if_missing('formations', 'start_date',          'DATE NULL');
CALL add_col_if_missing('formations', 'end_date',            'DATE NULL');

-- groups
CALL add_col_if_missing('groups', 'teacher_id',   'BIGINT UNSIGNED NULL');
CALL add_col_if_missing('groups', 'classroom_id', 'BIGINT UNSIGNED NULL');
CALL add_col_if_missing('groups', 'start_date',   'DATE NULL');
CALL add_col_if_missing('groups', 'end_date',     'DATE NULL');
CALL add_col_if_missing('groups', 'max_students', 'INT NOT NULL DEFAULT 30');

-- classrooms
CALL add_col_if_missing('classrooms', 'description', 'TEXT NULL');

-- contact_infos
CALL add_col_if_missing('contact_infos', 'fb',        'VARCHAR(255) NULL');
CALL add_col_if_missing('contact_infos', 'whatsapp',  'VARCHAR(255) NULL');
CALL add_col_if_missing('contact_infos', 'linkedin',  'VARCHAR(255) NULL');
CALL add_col_if_missing('contact_infos', 'youtube',   'VARCHAR(255) NULL');
CALL add_col_if_missing('contact_infos', 'instagram', 'VARCHAR(255) NULL');

-- attendance
CALL add_col_if_missing('attendance', 'subject_name', "VARCHAR(255) NOT NULL DEFAULT ''");
CALL add_col_if_missing('attendance', 'scan_time',    'TIME NULL');

-- attendance_validations
CALL add_col_if_missing('attendance_validations', 'subject_name', "VARCHAR(255) NOT NULL DEFAULT ''");
CALL add_col_if_missing('attendance_validations', 'validated_by', 'BIGINT UNSIGNED NULL');

-- payment_history
CALL add_col_if_missing('payment_history', 'subscription_plan', 'VARCHAR(20) NULL');
CALL add_col_if_missing('payment_history', 'promo_code_id',     'BIGINT UNSIGNED NULL');
CALL add_col_if_missing('payment_history', 'discount_percent',  'DECIMAL(5,2) NOT NULL DEFAULT 0');

-- weekly_schedule_entries
CALL add_col_if_missing('weekly_schedule_entries', 'classroom_id', 'BIGINT UNSIGNED NULL');

-- quran_memorization
CALL add_col_if_missing('quran_memorization', 'cycle',        'VARCHAR(100) NULL');
CALL add_col_if_missing('quran_memorization', 'formation_id', 'BIGINT UNSIGNED NULL');
CALL add_col_if_missing('quran_memorization', 'level',        'VARCHAR(100) NULL');

-- ─── Cleanup procedure ────────────────────────────────────────────────────────
DROP PROCEDURE IF EXISTS add_col_if_missing;

-- ─── Fix attendance_validations unique index to include subject_name ──────────
DROP PROCEDURE IF EXISTS add_idx_if_missing;
DELIMITER //
CREATE PROCEDURE add_idx_if_missing()
BEGIN
  -- Drop old partial unique keys if present
  IF EXISTS (
    SELECT 1 FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'attendance_validations'
      AND index_name = 'group_id'
  ) THEN
    ALTER TABLE attendance_validations DROP INDEX `group_id`;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'attendance_validations'
      AND index_name = 'date'
  ) THEN
    ALTER TABLE attendance_validations DROP INDEX `date`;
  END IF;

  -- Add new composite unique index if not present
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name  = 'attendance_validations'
      AND index_name  = 'idx_val_unique'
  ) THEN
    ALTER TABLE attendance_validations
      ADD UNIQUE INDEX idx_val_unique (group_id, date, subject_name);
  END IF;
END //
DELIMITER ;
CALL add_idx_if_missing();
DROP PROCEDURE IF EXISTS add_idx_if_missing;

SELECT 'Migration complete!' AS status;
