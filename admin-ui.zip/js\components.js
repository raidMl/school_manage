/**
 * components.js — Loads shared layout partials and initialises sidebar behaviour
 */

// Inject translation script synchronously with cache buster
document.write('<script src="js/i18n.js?v=' + new Date().getTime() + '"></script>');

(function () {
  'use strict';

  var BASE = 'partials/';

  // ── Sidebar state ────────────────────────────────────────────────────────────
  var SB_KEY = 'sb_collapsed';
  var isFixed = localStorage.getItem('app_sb_fixed') === 'true';

  // Apply fixed mode BEFORE sidebar partial loads so CSS takes effect immediately
  if (isFixed) {
    document.body.classList.add('sb-fixed');
    if (localStorage.getItem(SB_KEY) === 'true') {
      document.body.classList.add('sb-collapsed');
    }
  }

  // Global toggle called by onclick in sidebar HTML
  window.sbToggleSidebar = function () {
    var isMobile = window.innerWidth <= 991;
    if (isMobile) {
      // On mobile/tablet, always toggle overlay drawer
      document.body.classList.toggle('sb-open');
      var sbMainMobile = document.querySelector('.sb-main');
      if (sbMainMobile) {
        sbMainMobile.style.marginRight = '';
        sbMainMobile.style.marginLeft = '';
      }
      return;
    }

    var isRtl = document.documentElement.dir === 'rtl';
    if (document.body.classList.contains('sb-fixed')) {
      // Fixed Mode: toggle collapsed (icon-only) state
      var isNowCollapsed = document.body.classList.toggle('sb-collapsed');
      localStorage.setItem(SB_KEY, isNowCollapsed ? 'true' : 'false');
      // Force immediate margin update (RTL-aware)
      var sbMain = document.querySelector('.sb-main');
      if (sbMain) {
        var margin = isNowCollapsed ? '68px' : 'var(--sb-width)';
        if (isRtl) {
          sbMain.style.marginRight = margin;
          sbMain.style.marginLeft = '';
        } else {
          sbMain.style.marginLeft = margin;
          sbMain.style.marginRight = '';
        }
      }
    } else {
      // Overlay Mode: show/hide sidebar
      document.body.classList.toggle('sb-open');
    }
  };

  // Ensure inline margins are cleaned up when resizing to mobile
  window.addEventListener('resize', function () {
    if (window.innerWidth <= 991) {
      var sbMain = document.querySelector('.sb-main');
      if (sbMain) {
        sbMain.style.marginRight = '';
        sbMain.style.marginLeft = '';
      }
    }
  });

  // Global toggle for submenu items
  window.sbToggle = function (linkEl) {
    if (document.body.classList.contains('sb-collapsed')) {
      // In collapsed mode, navigate to the first submenu link instead of opening
      var submenu = linkEl.nextElementSibling;
      if (submenu && submenu.classList.contains('sb-submenu')) {
        var firstLink = submenu.querySelector('a');
        if (firstLink && firstLink.href) {
          window.location.href = firstLink.href;
          return;
        }
      }
    }

    var item = linkEl.closest('.sb-item');
    if (!item) return;
    var wasOpen = item.classList.contains('open');
    // Close siblings
    var siblings = item.parentElement.querySelectorAll('.sb-item.open');
    siblings.forEach(function (s) { s.classList.remove('open'); });
    if (!wasOpen) item.classList.add('open');
  };

  // Close sidebar when overlay is clicked (mobile)
  document.addEventListener('click', function (e) {
    if (e.target.id === 'sb-overlay') {
      document.body.classList.remove('sb-open');
    }
    // Close topbar dropdowns on outside click
    if (!e.target.closest('#topbar-user-menu')) {
      var um = document.getElementById('topbar-user-menu');
      if (um) um.classList.remove('open');
    }
    if (!e.target.closest('#lang-wrap') && !e.target.closest('.lang-wrap')) {
      document.querySelectorAll('.lang-wrap').forEach(function (w) { w.classList.remove('open'); });
    }
  });



  // Mark active nav item based on current page's data-page attribute
  function markActiveNav() {
    var page = (document.body && document.body.getAttribute('data-page')) || '';
    if (!page) return;

    var items = document.querySelectorAll('#app-sidebar [data-menu]');
    items.forEach(function (item) {
      var isMatch = item.getAttribute('data-menu') === page;
      var link = item.querySelector('.sb-link');
      var submenuLinks = item.querySelectorAll('.sb-submenu a');

      if (isMatch) {
        if (link) link.classList.add('active');
        item.classList.add('open');
      }
      // Active on submenu link
      submenuLinks.forEach(function (a) {
        var href = a.getAttribute('href') || '';
        var currentFile = window.location.pathname.split('/').pop() || 'index.html';
        if (href === currentFile) {
          a.classList.add('active');
          item.classList.add('open');
          if (link) link.classList.add('active');
        }
      });
    });

    // Update topbar page title
    var activeLink = document.querySelector('#app-sidebar .sb-link.active .sb-label');
    var title = document.getElementById('sb-page-title');
    if (title && activeLink) title.textContent = activeLink.textContent.trim();
  }

  // ── Partial loader ───────────────────────────────────────────────────────────
  function afterLoad(name, el) {
    // Translate the newly-injected partial element only
    if (window.AppI18n && el) {
      window.AppI18n.translateAll(el);
    }
    if (window.SchoolBackend && typeof window.SchoolBackend.afterPartialLoad === 'function') {
      window.SchoolBackend.afterPartialLoad(name);
    }
  }

  function loadPartial(placeholderId, file, name, callback) {
    var el = document.getElementById(placeholderId);
    if (!el) { if (callback) callback(); return; }

    var xhr = new XMLHttpRequest();
    xhr.open('GET', BASE + file, true);
    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 400) {
        el.innerHTML = xhr.responseText;
        
        // Prevent CSS transition flashing on newly inserted elements
        var sb = document.getElementById('app-sidebar');
        if (name === 'sidebar' && sb) {
          sb.style.transition = 'none';
          void sb.offsetHeight; // force reflow
          sb.style.transition = '';
        }

        afterLoad(name, el);
      }
      if (callback) callback();
    };
    xhr.onerror = function () { if (callback) callback(); };
    xhr.send();
  }

  function loadComponents() {
    // Load sidebar → header → footer in sequence
    loadPartial('sidebar-placeholder', 'sidebar.html', 'sidebar', function () {
      markActiveNav();

      loadPartial('header-placeholder', 'header.html', 'header', function () {
        loadPartial('footer-placeholder', 'footer.html', 'footer', function () {
          // Final pass: translate the static page content (non-partial elements)
          if (window.AppI18n) {
            window.AppI18n.translateAll(document.body);
          }
        });
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadComponents);
  } else {
    loadComponents();
  }
})();
